import Vue from 'vue'
import { EventEmitter } from 'events'
import VueResource from 'vue-resource'

Vue.use(VueResource)

const store = new EventEmitter()

export default store

store.fetchItems = (api) => {
  return this.$http.get('/static/api/que.json', {}, {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    emulateJSON: true
  }).then(function (response) {
    var data = response.data
    var questionJSON = data.data
    this.items = questionJSON
    // 默认显示第一题
    this.questionIndex = this.quetitArry[0]
  }, function (response) {
    console.log('error')
  })
}