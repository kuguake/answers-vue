<template>
  <div>{{ user }} 欢迎你</div>
</template>

<script>
export default {
  data () {
    return {
      user: '李伟涛'
    }
  }
}
</script>