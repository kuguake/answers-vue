<template>
  <div class="question-box">
    <h2 id="cut">{{ cut }}</h2>
    <p class="guan"><img src="../assets/img/1.png"></p>
    <p><input type="hidden" id="cj">{{myAnswer}}</p>
    <div id="queslist">
      <div class="quespart" v-for="value in items" v-show="$index == 0 ? true : false">
        <div class="ques1 ques">
        <h2>{{questionIndex}}:{{value.question}}</h2>
        <ul class="ops">
          <li @click="getQuestionAnswer($event)">{{value.answer1}}<input type="radio" name="{{value.id}}" value="A" class="hide"/></li>
          <li @click="getQuestionAnswer($event)">{{value.answer2}}<input type="radio" name="{{value.id}}" value="B" class="hide"/></li>
          <li @click="getQuestionAnswer($event)">{{value.answer3}}<input type="radio" name="{{value.id}}" value="C" class="hide"/></li>
        </ul>
        </div>
        <div class="next-btn"><a href="javascript:;" v-on:click="getNextQuestion($event)" class="btn btn_warn nextque" >{{btnText}}</a></div>
      </div>
    </div>
    <div class="bar">
      <dl></dl>
    </div>
    <layer></layer>
  </div>
  
</template>
<script>
import $ from 'webpack-zepto'
import store from '../store'
import Layer from './Laryer.vue'
export default {
  data () {
    return {
      quetitArry: ['问题一', '问题二', '问题三', '问题四', '问题五', '问题六', '问题七', '问题八', '问题九', '问题十'],
      cutArry: ['开始', '第一关', '第二关', '第三关', '第四关', '第五关'],
      cut: '第一关',
      btnText: '下一题',
      items: '',
      myAnswer: [],
      questionIndex: ''
    }
  },
  components: {
    Layer
  },
  ready () {
    store.fetchItems('/static/api/que.json')
    // this.$http.get('/static/api/que.json', {}, {
    //   headers: {
    //     'X-Requested-With': 'XMLHttpRequest'
    //   },
    //   emulateJSON: true
    // }).then(function (response) {
    //   var data = response.data
    //   var questionJSON = data.data
    //   this.items = questionJSON
    //   // 默认显示第一题
    //   this.questionIndex = this.quetitArry[0]
    // }, function (response) {
    //   console.log('error')
    // })
  },
  methods: {
    // 获得下一题
    getNextQuestion: function (event) {
      var el = event.currentTarget
      var answerValue = $('#cj').val()
      if (answerValue === '') {
        return false
      }
      if ($(el).hasClass('nextque')) {
        this.items.splice(0, 1)
      } else {
        setTimeout(this.SubmitAnswer(), 200)
      }
      var arraylength = this.items.length
      var myAnswerlength = this.myAnswer.length
      this.myAnswer.push(answerValue)
      // 题标递进+1
      this.questionIndex = this.quetitArry[myAnswerlength + 1]
      $('#cj').val('')
      if (arraylength === 1) {
        $('.next-btn a').removeClass('nextque').addClass('submit')
        this.btnText = '提交'
      }
    },
    getQuestionAnswer: function (event) {
      var el = event.currentTarget
      var ansVal = $(el).find('input').val()
      $('.ops li').removeClass('ops-active')
      $(el).addClass('ops-active')
      $('#cj').val('').val(ansVal)
    },
    SubmitAnswer: function () {
      $('.layer').addClass('success-bg')
      $('.layer-box').show()
    }
  }
}
</script>
<style lang="less">
.question-box{
  background: url(../assets/img/main-bg.jpg) no-repeat 0 0;
  background-size: cover;
  min-height: 100%;
  padding-bottom: 1.4rem;
  h2{
    text-align: center;
    font-size: 3.0rem;
    padding: 10% 0 5;
  }
  .guan{
    text-align: center;
    img{
      width: 20.4%;
    }
  }
  .ques1{
    h2{
      font-size: 2rem;
      width: 70%;
      margin: 0 auto;
      text-align: left;
      font-weight: normal;
    }
    .ops{
      margin: 0 auto;
      width: 70%;
      li{
        width: 100%;
        background-color: #39a47a;
        line-height: 4rem;
        border-radius: 10px;
        font-size: 1.6rem;
        text-align: center;
        color: #FFF;
        margin-bottom: 2rem;
        &:hover,&:active{
          background-color: #e6595f;
        }
      }
      .ops-active{
          background-color: #e6595f;
      }
    }
  }
  .next-btn{
    .btn_warn{
      width: 50%;
      line-height: 3
    }
  }
  .bar{
    padding-top: 10%;
    display:-moz-box;
    -moz-box-pack:center;
    display:-webkit-box;
    -webkit-box-pack:center;
    dl{
      dt,dd{
        float: left;

      }
      dt{
        width: 1rem;
        height: 1rem;
        display:-webkit-box;
        -webkit-box-align:center;
        padding-top: 0.2rem;
        hr{
          width: 100%;
          height: 1px;
          border: 0;
          border-top: 4px solid #999;
        }
      }
      dd{
        width: 1.5rem;
        height: 1.5rem;
        border-radius: 50%;
        background-color: #999;
        color: #FFF;
        line-height: 1.5rem;
        text-align: center;
        font-size: 1rem;
        transition:background  1s;
        -moz-transition:background  1s; 
        -webkit-transition:background  1s; 
        -o-transition:background  1s; 
      }
      .bar-ok{
        background-color: #f23d3a;
      }
    }
  }

}
</style>