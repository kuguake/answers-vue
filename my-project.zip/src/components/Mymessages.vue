<template>
  <div>我的信息页</div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>