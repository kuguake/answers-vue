<template>
  <div>我的积分页</div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>